<?php include('config/constants.php'); ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
      integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn"
      crossorigin="anonymous"
    />

    <title>login admin</title>
  </head>
  <body>
    <div class="container p-4 mt-3">
        <h1 class="mb-5 ">Add Admin</h1>
      <form action="" method="POST">
        <div class="form-group">
            <label for="exampleInputEmail1">Full Name:</label>
            <input
              type="text"
              name ="full_name"
              class="form-control"
              id=""
              placeholder="Enter your full name"
              aria-describedby="emailHelp"
            />
        </div>

        <div class="form-group">
            <label for="exampleInputEmail1">Username</label>
            <input
              type="text"
              name ="username"
              class="form-control"
              id=""
              placeholder="Enter your username"
              aria-describedby="emailHelp"
            />
        </div>
          
        <div class="form-group">
          <label for="exampleInputPassword1">Password</label>
          <input
            type="password"
            class="form-control"
            id=""
            name="password"
            placeholder="Enter your password"
          />
        </div>
        
        <input type="submit" name="submit" value="Submit" class="btn btn-primary">

      </form>
    </div>
    <script
      src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
      integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF"
      crossorigin="anonymous"
    ></script>
  </body>
</html>

<?php
//Process the value from form and save it in database.
//Check whethe the submit button is clicked or not
if(isset($_POST['submit'])){
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    //Sql Query to save the data into the database
    $sql = "insert into tbl_admin set full_name ='$full_name',
    username='$username',
    password = '$password'";

    // Execute Query and save data in database
    //Below one to connection to database
    $conn = mysqli_connect('localhost', 'root', '') or die(mysqli_error());

    //Select the database
    $db_select = mysqli_select_db($conn, 'food-order');

    $res = mysqli_query($conn, $sql) or die(mysqli_error());
    
    //Check data is executed or not
    if($res==TRUE){
       echo "Data Inserted Successfully";
       header('location:'.SITEURL);
    }
    else{
        echo "Not";
    }
}

else{
    echo "Not Okay";
}

?>