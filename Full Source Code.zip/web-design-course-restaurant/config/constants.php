<?php

    //Create constants to store non repeating values
    define('LOCALHOST', 'localhost');
    define('SITEURL', 'http://localhost/food_order/web-design-course-restaurant/');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');
    define('DB_NAME', 'food-order');

  //Below one to connection to database
  $conn = mysqli_connect(LOCALHOST, DB_USERNAME, DB_PASSWORD) or die(mysqli_error());

  //Select the database
  $db_select = mysqli_select_db($conn, DB_NAME);

?>