<?php include('config/constants.php'); ?>

<?php

    $id = $_GET['id'];

    //Query to delete 
    $sql = "delete from tbl_admin where id= $id";

    // Execute the query
    $res = mysqli_query($conn, $sql);

    if($res ==true){
        header('location:'.SITEURL);
    }
    else{
        echo "Error";
    }

?>