<?php include('config/constants.php'); ?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">

    <title> Manage Admin</title>
    <style>
       
    </style>
  </head>
  <body>

    <div class="container" align="center">
        <h1 class="pt-2 m-4">Manage Admin</h1>

      <div class="text-left">
      <a href="add-admin.php" class="btn btn-dark">Add Admin</a>
      </div>
        <table class="table mt-3">
            <tr class="table p-5 mt-6" align="center">
                <th align="center">Sr.No</th>
                <th>Full name</th>
                <th>Username</th>
                <th>Action</th>
            </tr>
            <?php

              //Query to display data
              $sql = "Select * from tbl_admin";
              //Execute query
              $res = mysqli_query($conn , $sql);

              //Check execute or not
              if($res == TRUE){

                $count = mysqli_num_rows($res);
                 //Create a variable as autoincrement
                $sn = 1;

                if($count>0){
                  while($rows = mysqli_fetch_assoc($res)){
                    $id = $rows['id'];
                    $full_name = $rows['full_name'];
                    $username = $rows['username'];

                    ?>

                    
            <tr class="table p-6 " align="center">
                <td><?php echo $sn++;?></td>
                <td><?php echo $full_name;?></td>
                <td><?php echo $username;?></td>
                <td class="p-2">

                <a href="<?php echo SITEURL;?>update-password.php?id=<?php echo $id;?>" class="btn btn-warning ">Password</a>

                <a href="<?php echo SITEURL;?>update-admin.php?id=<?php echo $id;?>" class="btn btn-primary">Update</a>

                <a href="<?php echo SITEURL;?>delete-admin.php?id=<?php echo $id;?>" class="btn btn-danger">Delete</a>
                </td>
            </tr> 

                    <?php
                  }
                }


              }
              else{

              }

            ?>


        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>

  </body>
</html>
