<?php include('config/constants.php'); ?>


<!DOCTYPE html>
<html lang="en">
<head>  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Instagram login page</title>
  <style>

    body{
      background-color: whitesmoke;
    }
    .card{
      background-color: white;
      display: flex;
      text-align: center;
      flex-direction: column;
      justify-content: center;
      border: 1px solid rgba(170, 160, 160, 0.39);
      }

      .card1{
        font-size: smaller;
        color:rgb(40, 40, 43);
        background-color: white;
      display: flex;
      text-align: center;
      flex-direction: column;
      justify-content: center;
      border: 1px solid black;
      margin-top: 10px;
      border: 1px solid rgba(170, 160, 160, 0.39);
      padding: 20px 0px ;
      font-family: 'Oxygen', sans-serif;

      }

    .container{
      padding: 31px 582px 0px 582px; 
      margin-top: 11%; 
    }
    .paragraph p{
      text-align: center;
      line-height: 0.1em;
      border-bottom: 1px solid rgba(170, 160, 160, 0.39);
      color:rgba(170, 160, 160, 0.39);
      width: 74%;
      margin: 20px 10px 10px 49px;
    }
    p span{
      padding: 0px 10px;
      background: white;
    }
    .image{
      display: inline;
    }
    button:hover{
        background-color: dodgerblue;
    }

    .imgbutton{
      background-color: transparent;
    }
    .username input{
      border: 1px solid rgba(200, 186, 186, 0.39);
      background-color: rgb(247, 247, 247);
      padding: 9px;
      border-radius: 2px;
      margin-bottom: 6px;
      font-family: 'Oxygen', sans-serif;
      font-size: small;
      color: rgb(107, 103, 103);
      
    }
    .password input{
      border: 1px solid rgba(200, 186, 186, 0.39);
      background-color: rgb(247, 247, 247);
      padding: 9px;
      border-radius: 2px;
      margin-bottom: 18px; 
      font-family: 'Oxygen', sans-serif; 
      font-size: small;    
      color: rgb(107, 103, 103);
    } 
 
    button{
      color: white;
      padding: 5px;
      border: 0px;
      width: 280px;
      background-color:  rgba(74, 193, 252, 0.39);

      border-radius: 4px;
      margin-bottom: 9px;

      
    }

    .paragraph{
      margin-bottom: 18px;
      font-size: 13px;
      font-family: 'Oxygen', sans-serif;

    }
    
    .image{  font-size: medium;
      margin-bottom: 15px;
      font-family: 'Oxygen', sans-serif;
      color: rgb(85, 85, 145);

    }

    .fpassword{
      margin-bottom: 5px;
      font-size: small;
      color:  rgb(104, 104, 160);
      margin-bottom: 20px;

font-family: 'Lobster', cursive;

font-family: 'Oxygen', sans-serif;

    }
    .span1{
      margin: 0px 0px 0px 6px;
    } 
    a{
      text-decoration: none;
      color: rgb(0, 128, 255);
    }

    .heading{
      font-family: 'Lobster', cursive;
      margin: 13px 0px;
    }
    .paragraph span{
      color:rgb(104, 104, 160);
    }

    .card2{
      text-align: center;

    }
    .cardParagraph{
      color:rgb(104, 104, 160); ;
    }

  </style>
</head>
<body>
    <form action="" method="post">

        
  <div class="container">
    <div class="card">
    <h1>Login</h1>

      <div class="heading">
        <img src="/images.png" width="190px" alt="">
      </div>

      <div class="username">
        <input type="text" name="username" id="usernameid" placeholder="Phone number, username or email" size="40px"  > 
      </div>

      <div class="password">
        <input type="password" name="password" id="password" placeholder="Password" size="40px">
      </div>

      <div class="button" >
        <button name="submit"><b>Log ln</b></button>
      </div>

    </div>

    <div class="card1">
      <span>Don't have an account?<a href="#"> </a></span>
    </div>

  </div>
  
    </form>
</body>
</html>
<?php
if(isset($_POST['submit'])){
    //Get the data 
    $username = $_POST['username'];
    $password = $_POST['password'];

    //Check whether the user with username  and password name exits or not
    $sql = "Select * from tbl_admin where username='$username' and password = '$password'";

    //Execute
    $res = mysqli_query($conn, $sql);

    $count = mysqli_num_rows($res); 

    if($count==1){
        echo "Succesful";
        header('location:'.SITEURL);
    }
    else{
        echo "failed";
    }

}
?>