<?php

    include('config/constants.php');

    //Destory the session 
    session_destroy();

    header('location:'.SITEURL.'login.php');

?>