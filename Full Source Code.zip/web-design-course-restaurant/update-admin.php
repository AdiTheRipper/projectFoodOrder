<?php include('config/constants.php'); ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
      integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn"
      crossorigin="anonymous"
    />

    <title>Update</title>
  </head>
  <body>
    <div class="container p-4 mt-3">
        <h1 class="mb-5 ">Update Admin</h1>

        <?php

        $id = $_GET['id'];

        //Query to delete 
        $sql = "Select * from tbl_admin where id = $id";

        // Execute the query
        $res = mysqli_query($conn, $sql);

        if($res == true){
            //Data avaliable or not
            $count = mysqli_num_rows($res);

            if($count==1){
                $row = mysqli_fetch_assoc($res);

                $full_name = $row['full_name'];
                $username = $row['username'];
            }
            else{
                header('location:'.SITEURL);
            }
        }
        
        ?>

      <form action="" method="POST">
        <div class="form-group">
            <label for="exampleInputEmail1">Full Name:</label>
            <input
              type="text"
              name ="full_name"
              class="form-control"
              id=""
              placeholder="Enter your full name"
              aria-describedby="emailHelp" value="<?php echo $full_name?>"
            />
        </div>

        <div class="form-group">
            <label for="exampleInputEmail1">Username</label>
            <input
              type="text"
              name ="username"
              class="form-control"
              id=""
              placeholder="Enter your username"
              aria-describedby="emailHelp" value="<?php echo $username?>"
            />
        </div>
          
   
        
        <input type="submit" name="submit" value="Submit" class="btn btn-primary">

      </form>
    </div>
    <script
      src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
      integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF"
      crossorigin="anonymous"
    ></script>
  </body>

  <?php
  
  //submit button clicked or not
  if(isset($_POST['submit'])){

    $id = $_GET['id'];
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];

    //SQL query to update admin
    $sql = "Update tbl_admin set 
    full_name = '$full_name',
    username = '$username'
    where id='$id'
    ";

    //Execute the query
    $res = mysqli_query($conn, $sql);

    if($res == true){
        echo "Updated succesfully";
        header('location:'.SITEURL);
    }
    else{
        echo "Error";
    }
}
  
  ?>
</html>
