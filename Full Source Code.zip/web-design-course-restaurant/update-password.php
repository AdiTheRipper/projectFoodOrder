<?php include('config/constants.php'); ?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
      integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn"
      crossorigin="anonymous"
    />

    <title>Update</title>
  </head>
  <body>
    <div class="container p-4 mt-3">
        <h1 class="mb-5 ">Change Password</h1>

        <?php

if(isset($_GET['id'])){
    $id = $_GET['id'];
}
        
        ?>

      <form action="" method="POST">
        <div class="form-group">
            <label for="exampleInputEmail1">Previous Password:</label>
            <input
              type="password"
              name ="new_password"
              class="form-control"
              id=""
              placeholder="Enter your Password"
              aria-describedby="emailHelp"
            />
        </div>  
        <div class="form-group">
            <label for="exampleInputEmail1">New Password:</label>
            <input
              type="password"
              name ="current_password"
              class="form-control"
              id=""
              placeholder="Enter your Password"
              aria-describedby="emailHelp"
            />
        </div>  
        <div class="form-group">
            <label for="exampleInputEmail1">Confirm Password:</label>
            <input
              type="password"
              name ="confirm_password"
              class="form-control"
              id=""
              placeholder="Enter your Password"
              aria-describedby="emailHelp"
            />
        </div>      
        
        <div>
            <input type="hidden" name="id" value ="<?php echo $id;?>">
               
        <input type="submit" name="submit" value="Change password" class="btn btn-primary">

        </div>
      </form>
    </div>
    <script
      src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
      integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF"
      crossorigin="anonymous"
    ></script>
  </body>

  <?php
  //Get the data
    if(isset($_POST['submit'])){
        $id = $_POST['id'];
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        //Check whether the current id and password  exists or not

        $sql = "Select * from tbl_admin where  id = $id and password ='$new_password'";

        // execute the query
        $res = mysqli_query($conn, $sql);


        if($res == true){
            $count = mysqli_num_rows($res);

            if($count==1){
                
                if($current_password == $confirm_password){
                    $sql2 = "update tbl_admin set password ='$current_password' where id = $id 
                    ";
                    //Execute query
                    $res2 = mysqli_query($conn, $sql2);

                    if($res == true){
                        echo "Password Change successfully";
                        header('location:'.SITEURL);
                    }
                    else{
                        echo "bad";
                    }
                }
            }
            else{
                echo "User doesn't exists";
            }
        }


    }
  
?>
</html>